<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CEPA - Sistema de Votação</title>
    <style>
        * {
            box-sizing: border-box;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
        }

        body {
            background-color: #e1f5fe; /* Tom de fundo verde-água bem claro */
            background: radial-gradient(circle, #f4fbf9 0%, #d8f3eb 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 20px;
        }

        .wrapper {
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 100%;
            max-width: 580px;
        }

        /* Ícone CEPA feito em CSS */
        .brand-icon {
            width: 56px;
            height: 56px;
            background-color: #006642;
            border-radius: 14px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            position: relative;
            box-shadow: 0 4px 10px rgba(0, 102, 66, 0.2);
            margin-bottom: 16px;
        }

        /* Simulação do monitor/check dentro do ícone */
        .brand-icon::before {
            content: '';
            width: 24px;
            height: 18px;
            border: 2px solid #ffffff;
            border-radius: 3px;
            position: absolute;
            top: 16px;
        }

        .brand-icon::after {
            content: '✓';
            color: #ffffff;
            font-size: 14px;
            font-weight: bold;
            position: absolute;
            top: 14px;
        }

        .brand-icon-base {
            width: 14px;
            height: 2px;
            background-color: #ffffff;
            position: absolute;
            bottom: 16px;
        }

        h1.brand-title {
            font-size: 28px;
            font-weight: 700;
            color: #006642;
            margin: 0 0 4px 0;
            letter-spacing: 0.5px;
        }

        p.brand-subtitle {
            font-size: 14px;
            color: #4a5568;
            margin: 0 0 32px 0;
        }

        /* Card de Login */
        .login-card {
            background-color: #ffffff;
            border-radius: 16px;
            padding: 40px;
            width: 100%;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
            margin-bottom: 24px;
        }

        .login-card h2 {
            font-size: 22px;
            color: #1a202c;
            margin: 0 0 6px 0;
            font-weight: 600;
        }

        .login-card p.instruction {
            font-size: 13px;
            color: #718096;
            margin: 0 0 24px 0;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-size: 14px;
            font-weight: 600;
            color: #1a202c;
            margin-bottom: 8px;
        }

        .form-group input {
            width: 100%;
            padding: 14px 16px;
            border: 1px solid #e2e8f0;
            background-color: #f7fafc;
            border-radius: 10px;
            font-size: 15px;
            color: #2d3748;
            outline: none;
            transition: all 0.2s ease;
        }

        .form-group input:focus {
            border-color: #006642;
            background-color: #ffffff;
            box-shadow: 0 0 0 3px rgba(0, 102, 66, 0.1);
        }

        .form-group input::placeholder {
            color: #a0aec0;
        }

        /* Botão */
        .btn-submit {
            width: 100%;
            background-color: #006642;
            color: #ffffff;
            border: none;
            padding: 14px;
            font-size: 15px;
            font-weight: 600;
            border-radius: 10px;
            cursor: pointer;
            transition: background-color 0.2s ease;
            margin-top: 8px;
        }

        .btn-submit:hover {
            background-color: #004d32;
        }

        /* Link do Administrador */
        .admin-footer {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            text-decoration: none;
            color: #718096;
            font-size: 13px;
            transition: color 0.2s ease;
        }

        .admin-footer:hover {
            color: #4a5568;
        }

        .admin-footer svg {
            width: 16px;
            height: 16px;
            fill: none;
            stroke: currentColor;
            stroke-width: 2;
        }

        .erro {
    color: #dc2626;
    font-size: 12px;
    display: block;
    margin-top: 6px;
}

.input-erro {
    border-color: #dc2626 !important;
    background: #fff5f5 !important;
}

.input-sucesso {
    border-color: #16a34a !important;
}

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto;
}

body{
    background:linear-gradient(135deg,#eefbf5,#d8f3eb);
    padding:20px;
}

/* CARD PRINCIPAL */
.card{
    max-width:1400px;
    margin:auto;
    background:white;
    padding:30px;
    border-radius:24px;
    box-shadow:0 20px 60px rgba(0,0,0,.08);
}

/* TOPO */
.topo{
    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:15px;
    flex-wrap:wrap;
}

h1{
    color:#006642;
    font-size:28px;
}

/* BOTÃO */
.btn{
    background:#006642;
    padding:12px 18px;
    border-radius:12px;
    color:white;
    text-decoration:none;
}

/* STATS */
.stats{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
    gap:15px;
    margin:25px 0;
}

.stat{
    background:#fff;
    padding:18px;
    border-radius:18px;
    box-shadow:0 8px 30px rgba(0,0,0,.05);
}

.stat h2{
    margin-top:10px;
    font-size:32px;
    color:#006642;
}

/* LAYOUT PRINCIPAL */
.painel-votos{
    display:flex;
    gap:20px;
    margin-top:20px;
}

/* BLOCO */
.bloco{
    flex:1;
    background:#fff;
    padding:18px;
    border-radius:18px;
    box-shadow:0 8px 30px rgba(0,0,0,.05);
    overflow:hidden;
}

/* TABELA RESPONSIVA */
table{
    width:100%;
    border-collapse:collapse;
    margin-top:15px;
    min-width:500px;
}

th{
    background:#006642;
    color:white;
    padding:12px;
    font-size:14px;
}

td{
    padding:12px;
    border-bottom:1px solid #eee;
    font-size:14px;
}

tr:hover{
    background:#f7fafc;
}

/* SCROLL HORIZONTAL EM MOBILE */
.bloco table{
    display:block;
    overflow-x:auto;
}

/* GRÁFICO */
.grafico-vertical{
    display:flex;
    align-items:flex-end;
    justify-content:space-around;
    height:300px;
    margin-top:20px;
    gap:6px;
    overflow-x:auto;
    padding-bottom:10px;
}

.coluna{
    text-align:center;
    flex:1;
    min-width:50px;
}

.barra{
    border-radius:8px 8px 0 0;
    width:35px;
    margin:0 auto;
    transition:0.3s ease;
}

.valor{
    font-size:12px;
    margin-top:6px;
}

.nome{
    font-size:11px;
    color:#555;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
}

/* MODAL */
.modal{
    position:fixed;
    inset:0;
    background:rgba(0,0,0,.45);
    display:flex;
    justify-content:center;
    align-items:center;
    opacity:0;
    pointer-events:none;
    transition:0.25s ease;
    z-index:999;
}

.modal.show{
    opacity:1;
    pointer-events:auto;
}

.box{
    background:#fff;
    padding:24px;
    border-radius:16px;
    text-align:center;
    max-width:90%;
    width:380px;
    transform:scale(0.85);
    transition:0.25s ease;
}

.modal.show .box{
    transform:scale(1);
}

/* RESPONSIVO */
@media (max-width:900px){

    body{
        padding:15px;
    }

    .painel-votos{
        flex-direction:column;
    }

    h1{
        font-size:22px;
    }

    .stats{
        grid-template-columns:repeat(auto-fit,minmax(140px,1fr));
    }

    table{
        min-width:100%;
    }

    .barra{
        width:28px;
    }
}

@media (max-width:480px){

    .card{
        padding:18px;
    }

    .stat h2{
        font-size:26px;
    }

    .btn{
        width:100%;
        text-align:center;
    }
}
    </style>
</head>
<body>

    <div class="wrapper">
        <div class="brand-icon">
            <div class="brand-icon-base"></div>
        </div>
        
        <h1 class="brand-title">CEPA</h1>
        <p class="brand-subtitle">Sistema de Votação</p>

        <div class="login-card">
            <h2>Área do Administrador</h2>
            <p class="instruction">Informe seu nome e a senha do administrador para analisar o desenvolvimento dos votos.</p>

<form id="loginForm" action="dashboard.php" method="POST">

    <div class="form-group">
        <label for="nome">Nome do(a) instrutor(a)</label>
        <input
            type="text"
            id="nome"
            name="nome"
            placeholder="Seu nome"
            autocomplete="off"
        >
        <small class="erro"></small>
    </div>

    <div class="form-group">
        <label for="matricula">Senha</label>
        <input
            type="password"
            id="matricula"
            name="senha"
            placeholder="Senha do admin"
            autocomplete="off"
        >
        <small class="erro"></small>
    </div>

    <button type="submit" class="btn-submit">
        Entrar
    </button>

</form>
        </div>

        <a href="login.php" class="admin-footer">
            <svg viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                <path d="m9 11 2 2 4-4"></path>
            </svg>
            Acesso aluno 
        </a>
    </div>

</body>

<script>
const form = document.getElementById("loginForm");

const nome = document.getElementById("nome");
const senha = document.getElementById("matricula");

function mostrarErro(campo, mensagem) {
    campo.classList.add("input-erro");
    campo.classList.remove("input-sucesso");

    campo.parentElement
        .querySelector(".erro")
        .textContent = mensagem;
}

function limparErro(campo) {
    campo.classList.remove("input-erro");

    if (campo.value.trim() !== "") {
        campo.classList.add("input-sucesso");
    }

    campo.parentElement
        .querySelector(".erro")
        .textContent = "";
}

form.addEventListener("submit", function(e) {

    e.preventDefault();

    let valido = true;

    // Nome
    if (nome.value.trim() === "") {
        mostrarErro(nome, "Informe seu nome.");
        valido = false;

    } else if (nome.value.trim().length < 3) {
        mostrarErro(nome, "Digite pelo menos 3 caracteres.");
        valido = false;

    } else {
        limparErro(nome);
    }

    // Senha
    if (senha.value.trim() === "") {
        mostrarErro(senha, "Informe a senha.");
        valido = false;

    } else if (senha.value !== "admin123") {
        mostrarErro(senha, "Senha inválida.");
        valido = false;

    } else {
        limparErro(senha);
    }

    if (valido) {
        form.submit();
    }

});

[nome, senha].forEach(campo => {
    campo.addEventListener("input", () => {

        if (campo.value.trim() !== "") {
            limparErro(campo);
        }

    });
});
</script>
</html>