<?php

include
"conexao.php";

$id=
intval(
$_POST["id"]
);

$sql=
$conn->prepare(

"

DELETE
FROM candidatos

WHERE id=?

"

);

$sql->bind_param(

"i",

$id

);

$sql->execute();

header(

"Location:
painel_admin.php"

);

exit;