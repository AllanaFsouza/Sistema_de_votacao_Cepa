<?php
session_start();

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");

include "conexao.php";

/* LOGIN ADMIN */
if ($_SERVER["REQUEST_METHOD"]=="POST") {

$nome=trim($_POST["nome"]);
$senha=trim($_POST["senha"]);

if($senha!="admin123"){
header("Location: login_adm.php");
exit;
}

$busca=$conn->prepare("SELECT id FROM instrutores WHERE nome=?");
$busca->bind_param("s",$nome);
$busca->execute();

if($busca->get_result()->num_rows==0){
$insert=$conn->prepare("INSERT INTO instrutores(nome) VALUES(?)");
$insert->bind_param("s",$nome);
$insert->execute();
}

$_SESSION["admin"]=$nome;
}

/* PROTEÇÃO */
if(!isset($_SESSION["admin"])){
header("Location: login_adm.php");
exit;
}

/* TOTAL VOTOS */
$total=$conn->query("
SELECT SUM(total_votos) AS total FROM candidatos
")->fetch_assoc();

$totalVotos=$total["total"] ?? 0;

/* LISTA (IMPORTANTE: inclui ID) */
$candidatos=$conn->query("
SELECT id,nome,numero,total_votos
FROM candidatos
ORDER BY numero
");

/* CORES */
$cores = [
"#006642","#38bdf8","#8b5cf6","#f59e0b",
"#ef4444","#14b8a6","#e879f9","#64748b"
];
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Painel Administrativo</title>

<style>
*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto;
}

body{
background:linear-gradient(135deg,#eefbf5,#d8f3eb);
padding:40px;
}

.card{
max-width:1400px;
margin:auto;
background:white;
padding:35px;
border-radius:28px;
box-shadow:0 20px 60px rgba(0,0,0,.08);
}

.topo{
display:flex;
justify-content:space-between;
align-items:center;
margin-bottom:35px;
}

h1{color:#006642;font-size:34px;}

.btn{
background:#006642;
padding:14px 22px;
border-radius:14px;
color:white;
text-decoration:none;
}

.stats{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
gap:20px;
margin-bottom:40px;
}

.stat{
background:#fff;
padding:25px;
border-radius:22px;
box-shadow:0 8px 30px rgba(0,0,0,.05);
}

.stat h2{
margin-top:10px;
font-size:40px;
color:#006642;
}

/* LAYOUT */
.painel-votos{
display:flex;
gap:30px;
align-items:flex-start;
margin-top:30px;
}

.bloco{
flex:1;
background:#fff;
padding:20px;
border-radius:20px;
box-shadow:0 8px 30px rgba(0,0,0,.05);
}

/* TABELA */
table{
width:100%;
border-collapse:collapse;
margin-top:15px;
}

th{
background:#006642;
color:white;
padding:16px;
}

td{
padding:16px;
border-bottom:1px solid #eee;
}

tr:hover{background:#f7fafc;}

/* GRÁFICO */
.grafico-vertical{
display:flex;
align-items:flex-end;
justify-content:space-around;
height:320px;
margin-top:30px;
gap:8px;
}

.coluna{
text-align:center;
flex:1;
}

.barra{
border-radius:8px 8px 0 0;
width:40px;
margin:0 auto;
transition:0.5s;
}

.valor{
font-size:12px;
margin-top:6px;
}

.nome{
font-size:11px;
color:#555;
white-space:nowrap;
overflow:hidden;
text-overflow:ellipsis;
}

@media (max-width:900px){
.painel-votos{flex-direction:column;}
}

.modal{
    position:fixed;
    inset:0;
    background:rgba(0,0,0,.4);
    display:none;
    justify-content:center;
    align-items:center;
    z-index:999;
}

.modal.show{
    display:flex;
}

.box{
    background:#fff;
    padding:30px;
    border-radius:16px;
    text-align:center;
    max-width:400px;
}

.modal{
    position:fixed;
    inset:0;
    background:rgba(0,0,0,.0);
    display:flex;
    justify-content:center;
    align-items:center;
    z-index:999;

    opacity:0;
    pointer-events:none;
    transition:0.25s ease;
}

.modal.show{
    opacity:1;
    background:rgba(0,0,0,.45);
    pointer-events:auto;
}

.box{
    background:#fff;
    padding:30px;
    border-radius:16px;
    text-align:center;
    max-width:400px;

    transform:scale(0.85);
    opacity:0;
    transition:0.25s ease;
}

.modal.show .box{
    transform:scale(1);
    opacity:1;
}
*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto;
}

body{
background:linear-gradient(135deg,#eefbf5,#d8f3eb);
padding:20px;
}

/* CARD PRINCIPAL */
.card{
max-width:1400px;
width:100%;
margin:auto;
background:white;
padding:25px;
border-radius:22px;
box-shadow:0 20px 60px rgba(0,0,0,.08);
}

/* TOPO */
.topo{
display:flex;
justify-content:space-between;
align-items:center;
margin-bottom:25px;
gap:15px;
flex-wrap:wrap;
}

.topo p{
font-size:14px;
}

h1{
color:#006642;
font-size:32px;
}

/* BOTÃO */
.btn{
background:#006642;
padding:12px 18px;
border-radius:12px;
color:white;
text-decoration:none;
}

/* STATS */
.stats{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(160px,1fr));
gap:15px;
margin-bottom:25px;
}

.stat{
background:#fff;
padding:18px;
border-radius:18px;
box-shadow:0 8px 30px rgba(0,0,0,.05);
}

.stat h2{
margin-top:10px;
font-size:28px;
color:#006642;
}

/* LAYOUT PRINCIPAL */
.painel-votos{
display:flex;
gap:20px;
align-items:flex-start;
margin-top:20px;
flex-wrap:wrap;
}

/* BLOCO (TABELA / GRÁFICO) */
.bloco{
flex:1;
min-width:320px;
background:#fff;
padding:18px;
border-radius:18px;
box-shadow:0 8px 30px rgba(0,0,0,.05);
}

/* TABELA */
table{
width:100%;
border-collapse:collapse;
margin-top:10px;
font-size:14px;
}

th{
background:#006642;
color:white;
padding:10px;
font-size:13px;
}

td{
padding:10px;
border-bottom:1px solid #eee;
}

tr:hover{
background:#f7fafc;
}

/* INPUT EDIT */
input[type=text]{
padding:6px;
border:1px solid #ccc;
border-radius:6px;
width:160px;
max-width:100%;
}

/* BOTÃO SALVAR */
button{
background:#006642;
color:white;
border:none;
padding:6px 12px;
border-radius:6px;
cursor:pointer;
transition:0.2s;
}

button:hover{
background:#005236;
}

/* GRÁFICO */
.grafico-vertical{
display:flex;
align-items:flex-end;
justify-content:flex-start;
gap:8px;
overflow-x:auto;
padding-bottom:10px;
height:280px;
}

.coluna{
min-width:55px;
flex:0 0 auto;
text-align:center;
}

.barra{
border-radius:8px 8px 0 0;
width:40px;
margin:0 auto;
transition:0.5s;
}

.valor{
font-size:12px;
margin-top:6px;
}

.nome{
font-size:11px;
color:#555;
white-space:nowrap;
overflow:hidden;
text-overflow:ellipsis;
}

/* MODAL ANIMADO */
.modal{
position:fixed;
inset:0;
background:rgba(0,0,0,0);
display:flex;
justify-content:center;
align-items:center;
z-index:999;
opacity:0;
pointer-events:none;
transition:0.25s ease;
}

.modal.show{
opacity:1;
background:rgba(0,0,0,0.45);
pointer-events:auto;
}

/* CAIXA */
.box{
background:#fff;
padding:28px;
border-radius:16px;
text-align:center;
max-width:380px;
width:90%;
transform:scale(0.85);
opacity:0;
transition:0.25s ease;
}

.modal.show .box{
transform:scale(1);
opacity:1;
}

/* RESPONSIVO MOBILE */
@media (max-width:768px){

body{
padding:12px;
}

h1{
font-size:24px;
}

.stat h2{
font-size:22px;
}

.topo{
flex-direction:column;
align-items:flex-start;
}

.bloco{
min-width:100%;
}

button{
width:auto;
}

input[type=text]{
width:100%;
}

}

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto;
}

body{
background:linear-gradient(135deg,#eefbf5,#d8f3eb);
padding:20px;
}

/* CARD PRINCIPAL */
.card{
max-width:1400px;
width:100%;
margin:auto;
background:white;
padding:25px;
border-radius:22px;
box-shadow:0 20px 60px rgba(0,0,0,.08);
}

/* TOPO */
.topo{
display:flex;
justify-content:space-between;
align-items:center;
margin-bottom:25px;
gap:15px;
flex-wrap:wrap;
}

h1{
color:#006642;
font-size:32px;
}

.topo p{
font-size:14px;
color:#444;
}

/* BOTÃO SAIR */
.btn{
background:#006642;
padding:12px 18px;
border-radius:12px;
color:white;
text-decoration:none;
display:inline-block;
}

/* STATS */
.stats{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(160px,1fr));
gap:15px;
margin-bottom:25px;
}

.stat{
background:#fff;
padding:18px;
border-radius:18px;
box-shadow:0 8px 30px rgba(0,0,0,.05);
}

.stat h2{
margin-top:10px;
font-size:28px;
color:#006642;
}

/* LAYOUT PRINCIPAL */
.painel-votos{
display:flex;
gap:20px;
flex-wrap:wrap;
align-items:flex-start;
margin-top:20px;
}

/* BLOCO */
.bloco{
flex:1;
min-width:320px;
background:#fff;
padding:18px;
border-radius:18px;
box-shadow:0 8px 30px rgba(0,0,0,.05);
}

/* TABELA */
table{
width:100%;
border-collapse:collapse;
margin-top:10px;
font-size:14px;
}

th{
background:#006642;
color:white;
padding:10px;
font-size:13px;
}

td{
padding:10px;
border-bottom:1px solid #eee;
}

tr:hover{
background:#f7fafc;
}

/* INPUT */
input[type=text]{
padding:6px;
border:1px solid #ccc;
border-radius:6px;
width:160px;
max-width:100%;
}

/* BOTÃO SALVAR */
button{
background:#006642;
color:white;
border:none;
padding:6px 12px;
border-radius:6px;
cursor:pointer;
transition:0.2s;
}

button:hover{
background:#005236;
}

/* GRÁFICO */
.grafico-vertical{
display:flex;
align-items:flex-end;
gap:8px;
overflow-x:auto;
padding-bottom:10px;
height:280px;
}

.coluna{
min-width:55px;
text-align:center;
flex:0 0 auto;
}

.barra{
border-radius:8px 8px 0 0;
width:40px;
margin:0 auto;
transition:0.5s;
}

.valor{
font-size:12px;
margin-top:6px;
}

.nome{
font-size:11px;
color:#555;
white-space:nowrap;
overflow:hidden;
text-overflow:ellipsis;
}

/* MODAL */
.modal{
position:fixed;
inset:0;
background:rgba(0,0,0,0);
display:flex;
justify-content:center;
align-items:center;
z-index:999;
opacity:0;
pointer-events:none;
transition:0.25s ease;
}

.modal.show{
opacity:1;
background:rgba(0,0,0,0.45);
pointer-events:auto;
}

.box{
background:#fff;
padding:28px;
border-radius:16px;
text-align:center;
max-width:380px;
width:90%;
transform:scale(0.85);
opacity:0;
transition:0.25s ease;
}

.modal.show .box{
transform:scale(1);
opacity:1;
}

/* =========================
   RESPONSIVO
========================= */

/* TABLET */
@media (max-width: 900px){

h1{
font-size:26px;
}

.card{
padding:18px;
}

.stat h2{
font-size:22px;
}
}

/* CELULAR */
@media (max-width: 768px){

body{
padding:12px;
}

.topo{
flex-direction:column;
align-items:flex-start;
}

.bloco{
min-width:100%;
}

input[type=text]{
width:100%;
}

button{
width:auto;
}
}

/* CELULAR PEQUENO */
@media (max-width: 480px){

h1{
font-size:22px;
}

.stat h2{
font-size:20px;
}

.box{
padding:22px;
}

button{
font-size:13px;
}
}

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto;
}

body{
    background:linear-gradient(135deg,#eefbf5,#d8f3eb);
    padding:20px;
}

/* CARD PRINCIPAL */
.card{
    max-width:1400px;
    margin:auto;
    background:white;
    padding:20px;
    border-radius:18px;
    box-shadow:0 20px 60px rgba(0,0,0,.08);
}

/* TOPO */
.topo{
    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:10px;
    flex-wrap:wrap;
}

h1{
    color:#006642;
    font-size:clamp(20px, 3vw, 32px);
}

.btn{
    background:#006642;
    padding:10px 16px;
    border-radius:10px;
    color:white;
    text-decoration:none;
}

/* STATS */
.stats{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(140px,1fr));
    gap:12px;
    margin:20px 0;
}

.stat{
    background:#fff;
    padding:16px;
    border-radius:14px;
    box-shadow:0 8px 20px rgba(0,0,0,.05);
}

.stat h2{
    font-size:22px;
    color:#006642;
}

/* LAYOUT PRINCIPAL */
.painel-votos{
    display:flex;
    gap:16px;
    flex-wrap:wrap;
}

/* BLOCOS */
.bloco{
    flex:1;
    min-width:300px;
    background:#fff;
    padding:16px;
    border-radius:14px;
    box-shadow:0 8px 25px rgba(0,0,0,.05);
}

/* TABELA RESPONSIVA */
table{
    width:100%;
    border-collapse:collapse;
    margin-top:10px;
    font-size:14px;
    min-width:500px;
}

.tabela-scroll{
    overflow-x:auto;
}

/* HEADER */
th{
    background:#006642;
    color:white;
    padding:10px;
    font-size:13px;
}

/* CELULAS */
td{
    padding:10px;
    border-bottom:1px solid #eee;
}

/* INPUT */
input[type=text]{
    padding:6px;
    border:1px solid #ccc;
    border-radius:6px;
    width:100%;
    max-width:160px;
}

/* BOTÃO */
button{
    background:#006642;
    color:white;
    border:none;
    padding:6px 10px;
    border-radius:6px;
    cursor:pointer;
}

/* GRÁFICO SCROLL HORIZONTAL */
.grafico-vertical{
    display:flex;
    gap:8px;
    overflow-x:auto;
    padding-bottom:10px;
    align-items:flex-end;
    height:260px;
}

.coluna{
    min-width:50px;
    text-align:center;
}

.barra{
    width:38px;
    border-radius:6px 6px 0 0;
}

/* MODAL */
.modal{
    position:fixed;
    inset:0;
    background:rgba(0,0,0,0);
    display:flex;
    justify-content:center;
    align-items:center;
    opacity:0;
    pointer-events:none;
    transition:0.25s ease;
}

.modal.show{
    opacity:1;
    background:rgba(0,0,0,0.45);
    pointer-events:auto;
}

.box{
    background:#fff;
    padding:22px;
    border-radius:14px;
    width:90%;
    max-width:360px;
}

/* 📱 MOBILE */
@media (max-width:768px){

    body{
        padding:12px;
    }

    .painel-votos{
        flex-direction:column;
    }

    input[type=text]{
        max-width:100%;
    }

    table{
        font-size:13px;
    }
}

</style>

</head>

<body>

<div class="card">

<div class="topo">
<div>
<h1>Painel Administrativo</h1>
<p>Instrutor: <strong><?= htmlspecialchars($_SESSION["admin"]) ?></strong></p>
</div>
<a href="logout.php" class="btn">Sair</a>
</div>

<hr>

<div class="stats">
<div class="stat">
<span>Total de votos</span>
<h2><?= $totalVotos ?></h2>
</div>

<div class="stat">
<span>Candidatos</span>
<h2><?= $candidatos->num_rows ?></h2>
</div>

<div class="stat">
<span>Status</span>
<h2>AO VIVO</h2>
</div>
</div>

<div class="painel-votos">

<!-- TABELA -->
<div class="bloco">
<h2>Resultado dos Votos</h2>

<table>
<tr>
<th>Número</th>
<th>Candidato</th>
<th>Total</th>
</tr>

<?php
$candidatos->data_seek(0);
while($c=$candidatos->fetch_assoc()):
?>
<tr>
<td><?= $c["numero"] ?></td>

<td>
<form action="editar_candidato.php" method="POST" style="display:flex;gap:10px;align-items:center;">

<input type="hidden" name="id" value="<?= $c["id"] ?>">

<input type="text"
name="nome"
value="<?= htmlspecialchars($c["nome"]) ?>"
style="padding:6px;border:1px solid #ccc;border-radius:6px;width:180px;">

<button type="button"
        onclick="abrirModal(this.form)"
        style="background:#006642;color:white;border:none;padding:6px 12px;border-radius:6px;cursor:pointer;">
    Salvar
</button>

</form>
</td>

<td><?= $c["total_votos"] ?></td>
</tr>
<?php endwhile; ?>
</table>

</div>

<!-- GRÁFICO -->
<div class="bloco">
<h2>Distribuição dos Votos</h2>

<?php
$candidatos->data_seek(0);

$dados=[];
$i=0;

while($c=$candidatos->fetch_assoc()){

$p=($totalVotos>0)
?($c["total_votos"]/$totalVotos)*100
:0;

$dados[]=[
"numero"=>$c["numero"],
"votos"=>$c["total_votos"],
"pct"=>$p,
"cor"=>$cores[$i%count($cores)]
];

$i++;
}
?>

<div class="grafico-vertical">

<?php foreach($dados as $d): ?>

<div class="coluna">

<div class="barra"
style="height:<?= max($d["pct"]*2.5,5) ?>px;background:<?= $d["cor"] ?>">
</div>

<div class="valor">
<?= $d["votos"] ?>
</div>

<div class="nome">
<?= "Cand. ".$d["numero"] ?>
</div>

</div>

<?php endforeach; ?>

</div>

</div>

</div>

</div>

<!-- MODAL CONFIRMAÇÃO -->
<div id="confirmModal" class="modal">
    <div class="box">
        <h2>Confirmar alteração</h2>
        <p>Tem certeza que deseja salvar o novo nome do candidato?</p>

        <div style="margin-top:20px;display:flex;gap:10px;justify-content:center;">
            <button onclick="confirmarEnvio()" style="background:#006642;color:#fff;padding:10px 20px;border:none;border-radius:8px;cursor:pointer;">
                Confirmar
            </button>

            <button onclick="fecharModal()" style="background:#ccc;padding:10px 20px;border:none;border-radius:8px;cursor:pointer;">
                Cancelar
            </button>
        </div>
    </div>
</div>

<script>
let formAtual = null;

/* ABRIR MODAL */
function abrirModal(form){
    formAtual = form;
    document.getElementById("confirmModal").classList.add("show");
}

/* FECHAR MODAL */
function fecharModal(){
    document.getElementById("confirmModal").classList.remove("show");
    formAtual = null;
}

/* CONFIRMAR ENVIO */
function confirmarEnvio(){
    if(formAtual){
        formAtual.submit();
    }
}

/* FECHAR CLICANDO FORA */
document.addEventListener("DOMContentLoaded", function () {

    const modal = document.getElementById("confirmModal");

    modal.addEventListener("click", function(e){
        if(e.target === modal){
            fecharModal();
        }
    });

});

/* AUTO REFRESH */
setInterval(() => {
    window.location.reload();
}, 6000);

</script>
</body>
</html>