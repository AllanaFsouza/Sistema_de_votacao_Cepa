<?php

session_start();

include "conexao.php";

if (!isset($_SESSION["eleitor"])) {

header("Location: login.php");
exit;

}

if (!isset($_POST["candidato"])) {

header("Location: votacao.php");
exit;

}

$eleitor=
intval($_SESSION["eleitor"]);

$candidato=
intval($_POST["candidato"]);


/* verifica se já votou */

$verifica=
$conn->prepare(

"
SELECT id
FROM votos
WHERE eleitor_id=?

"

);

$verifica->bind_param(
"i",
$eleitor
);

$verifica->execute();

if (

$verifica
->get_result()
->num_rows > 0

) {

session_destroy();

?>

<!DOCTYPE html>

<html lang="pt-BR">

<head>

<meta charset="UTF-8">

<title>CEPA</title>

<style>

*{
box-sizing:border-box;
font-family:Arial;
}

body{

margin:0;

height:100vh;

display:flex;

justify-content:center;

align-items:center;

background:
radial-gradient(
circle,
#f4fbf9 0%,
#d8f3eb 100%
);

}

.modal{

background:white;

width:100%;

max-width:420px;

padding:35px;

border-radius:20px;

text-align:center;

box-shadow:
0 20px 40px
rgba(0,0,0,.12);

}

.modal-icon{

width:70px;

height:70px;

margin:auto;

border-radius:50%;

background:#fff5f5;

color:#e53e3e;

font-size:34px;

display:flex;

align-items:center;

justify-content:center;

margin-bottom:18px;

}

h2{

margin:0 0 10px;

color:#1a202c;

}

p{

color:#718096;

line-height:1.6;

margin-bottom:24px;

}

button{

width:100%;

padding:14px;

background:#006642;

color:white;

border:none;

border-radius:10px;

font-size:15px;

cursor:pointer;

}

button:hover{

background:#004d32;

}

/* =========================
   RESPONSIVIDADE GERAL
========================= */

@media (max-width: 900px) {

    body {
        padding: 15px;
    }

    .modal {
        max-width: 90%;
        padding: 25px;
    }

    h2 {
        font-size: 20px;
    }

    p {
        font-size: 14px;
    }

    button {
        font-size: 14px;
        padding: 12px;
    }
}

@media (max-width: 480px) {

    .modal {
        padding: 22px;
        border-radius: 16px;
    }

    .icon {
        width: 60px;
        height: 60px;
        font-size: 28px;
    }

    h2 {
        font-size: 18px;
    }

    p {
        font-size: 13px;
        line-height: 1.4;
    }

    button {
        padding: 12px;
        font-size: 14px;
    }
}

/* melhora centralização em telas muito pequenas */
@media (max-width: 360px) {

    .modal {
        width: 95%;
    }
}

</style>

</head>

<body>

<div class="modal">

<div class="modal-icon">

⚠

</div>

<h2>

Voto já registrado

</h2>

<p>

Este aluno já realizou uma votação anteriormente.

</p>

<button onclick="voltar()">

Voltar ao Login

</button>

</div>

<script>

function voltar(){

window.location=
"login.php";

}

</script>

</body>

</html>

<?php

exit;

}


/* verifica candidato */

$cand=
$conn->prepare(

"
SELECT id
FROM candidatos
WHERE id=?

"

);

$cand->bind_param(
"i",
$candidato
);

$cand->execute();

if(

$cand
->get_result()
->num_rows===0

){

die(
"Candidato inexistente."
);

}


/* salva voto */

$insert=
$conn->prepare(

"
INSERT INTO votos
(
eleitor_id,
candidato_id
)

VALUES
(
?,
?
)

"

);

$insert->bind_param(
"ii",
$eleitor,
$candidato
);

if(
!$insert->execute()
){

die(
"Erro ao salvar voto."
);

}


/* soma total */

$conn->query(

"
UPDATE candidatos

SET total_votos=
total_votos+1

WHERE id=$candidato

"

);


/* mostra modal */

header(
"Location: votacao.php?sucesso=1"
);

exit;

?>