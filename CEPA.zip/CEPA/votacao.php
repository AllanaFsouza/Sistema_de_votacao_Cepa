<?php
session_start();
include "conexao.php";

if (!isset($_SESSION["eleitor"])) {
    header("Location: login.php");
    exit;
}

$mostrarSucesso = isset($_GET["sucesso"]);

$sql = "
SELECT
id,
nome,
numero
FROM candidatos
ORDER BY numero
";

$resultado = $conn->query($sql);
?>

<!DOCTYPE html>

<html lang="pt-BR">

<head>

<meta charset="UTF-8">

<title>CEPA - Escolha seu Candidato</title>

<style>

*{
box-sizing:border-box;
font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial;
}

body{
margin:0;
padding:40px;
background: radial-gradient(circle at top, #f4fbf9 0%, #d8f3eb 100%);
color:#1f2937;
}

/* CONTAINER */
.container{
max-width:900px;
margin:auto;
}

/* TÍTULO */
h1{
color:#006642;
font-size:32px;
margin-bottom:10px;
}

/* GRID */
.candidates-grid{
display:grid;
grid-template-columns:repeat(auto-fit, minmax(260px, 1fr));
gap:18px;
margin-top:30px;
}

/* CARD */
.candidate-card{
background:white;
padding:22px;
border-radius:18px;
cursor:pointer;
display:flex;
justify-content:space-between;
align-items:center;

border:2px solid transparent;

box-shadow:0 10px 25px rgba(0,0,0,0.05);

transition:0.2s ease;
}

.candidate-card:hover{
transform:translateY(-3px);
box-shadow:0 14px 35px rgba(0,0,0,0.08);
}

/* SELECIONADO */
.candidate-card.selected{
border-color:#006642;
background:#eafaf2;
box-shadow:0 0 0 3px rgba(0,102,66,0.15);
}

/* TEXTO */
.candidate-card h2{
margin:5px 0 0;
font-size:18px;
color:#111827;
}

.candidate-card div{
font-size:14px;
color:#4b5563;
}

/* RADIO OCULTO */
input[type=radio]{
display:none;
}

/* BOTÃO */
button{
background:#006642;
color:white;
border:none;
padding:14px 34px;
border-radius:12px;
cursor:pointer;
font-size:15px;

transition:0.2s ease;
}

button:hover{
background:#005236;
transform:translateY(-2px);
}

/* AÇÕES */
.actions{
margin-top:30px;
text-align:right;
}

/* MODAL */
.modal{
position:fixed;
inset:0;
background:rgba(0,0,0,0.45);
display:none;
justify-content:center;
align-items:center;
}

.modal.show{
display:flex;
}

.box{
background:white;
padding:35px;
border-radius:18px;
text-align:center;
max-width:380px;
box-shadow:0 20px 60px rgba(0,0,0,0.2);
}

.box h2{
color:#111827;
margin-bottom:10px;
}

.box p{
color:#6b7280;
}

.box button{
margin-top:20px;
width:100%;
}

/* MODAL base (já existe, mas pode manter assim) */
.modal{
position:fixed;
inset:0;
background:rgba(0,0,0,0.45);
display:none;
justify-content:center;
align-items:center;
}

/* ativa */
.modal.show{
display:flex;
animation: fadeBg 0.25s ease forwards;
}

/* caixa do modal */
.box{
background:white;
padding:35px;
border-radius:18px;
text-align:center;
max-width:380px;
box-shadow:0 20px 60px rgba(0,0,0,0.2);

/* animação nova */
animation: popIn 0.35s cubic-bezier(0.2, 0.9, 0.3, 1);
}

/* fundo escurecendo */
@keyframes fadeBg{
from { background:rgba(0,0,0,0); }
to   { background:rgba(0,0,0,0.45); }
}

/* entrada da caixa */
@keyframes popIn{
0%{
transform:translateY(20px) scale(0.92);
opacity:0;
}
100%{
transform:translateY(0) scale(1);
opacity:1;
}
}

/* =========================
   RESPONSIVIDADE COMPLETA
========================= */

/* Tablets */
@media (max-width: 900px) {

    body {
        padding: 20px;
    }

    h1 {
        font-size: 26px;
        text-align: center;
    }

    .container {
        padding: 0 10px;
    }

    .candidate-card {
        padding: 18px;
    }

    .actions {
        text-align: center;
    }

    button {
        width: 100%;
        padding: 14px;
    }
}

/* Celulares médios */
@media (max-width: 600px) {

    h1 {
        font-size: 22px;
    }

    .candidates-grid {
        grid-template-columns: 1fr;
        gap: 12px;
    }

    .candidate-card {
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
    }

    .candidate-card div:last-child {
        align-self: flex-end;
        font-size: 20px;
    }

    .box {
        width: 90%;
        padding: 25px;
    }
}

/* Celulares pequenos */
@media (max-width: 400px) {

    body {
        padding: 15px;
    }

    h1 {
        font-size: 20px;
    }

    .candidate-card {
        padding: 14px;
    }

    .box {
        padding: 20px;
        border-radius: 14px;
    }

    button {
        font-size: 14px;
    }
}

*{
box-sizing:border-box;
font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial;
}

body{
margin:0;
padding:40px;
background: radial-gradient(circle at top, #f4fbf9 0%, #d8f3eb 100%);
color:#1f2937;
}

/* CONTAINER */
.container{
max-width:900px;
margin:auto;
}

/* TÍTULO */
h1{
color:#006642;
font-size:32px;
margin-bottom:10px;
text-align:center;
}

/* GRID */
.candidates-grid{
display:grid;
grid-template-columns:repeat(auto-fit, minmax(260px, 1fr));
gap:18px;
margin-top:30px;
}

/* CARD */
.candidate-card{
background:white;
padding:22px;
border-radius:18px;
cursor:pointer;
display:flex;
justify-content:space-between;
align-items:center;

border:2px solid transparent;
box-shadow:0 10px 25px rgba(0,0,0,0.05);
transition:0.2s ease;
}

.candidate-card:hover{
transform:translateY(-3px);
box-shadow:0 14px 35px rgba(0,0,0,0.08);
}

/* SELECIONADO */
.candidate-card.selected{
border-color:#006642;
background:#eafaf2;
box-shadow:0 0 0 3px rgba(0,102,66,0.15);
}

/* TEXTO */
.candidate-card h2{
margin:5px 0 0;
font-size:18px;
color:#111827;
}

.candidate-card div{
font-size:14px;
color:#4b5563;
}

/* RADIO OCULTO */
input[type=radio]{
display:none;
}

/* BOTÃO */
button{
background:#006642;
color:white;
border:none;
padding:14px 34px;
border-radius:12px;
cursor:pointer;
font-size:15px;
transition:0.2s ease;
}

button:hover{
background:#005236;
transform:translateY(-2px);
}

/* AÇÕES */
.actions{
margin-top:30px;
text-align:right;
}

/* MODAL */
.modal{
position:fixed;
inset:0;
background:rgba(0,0,0,0.45);
display:none;
justify-content:center;
align-items:center;
padding:20px;
}

.modal.show{
display:flex;
animation: fadeBg 0.25s ease forwards;
}

.box{
background:white;
padding:35px;
border-radius:18px;
text-align:center;
width:100%;
max-width:380px;
box-shadow:0 20px 60px rgba(0,0,0,0.2);
animation: popIn 0.35s cubic-bezier(0.2, 0.9, 0.3, 1);
}

/* ANIMAÇÕES */
@keyframes fadeBg{
from { background:rgba(0,0,0,0); }
to   { background:rgba(0,0,0,0.45); }
}

@keyframes popIn{
0%{
transform:translateY(20px) scale(0.92);
opacity:0;
}
100%{
transform:translateY(0) scale(1);
opacity:1;
}
}

/* =========================
   RESPONSIVIDADE
========================= */

@media (max-width: 900px){
body{
padding:20px;
}

h1{
font-size:26px;
}

.actions{
text-align:center;
}

button{
width:100%;
}
}

@media (max-width: 600px){

h1{
font-size:22px;
}

.candidate-card{
flex-direction:column;
align-items:flex-start;
gap:10px;
}

.candidate-card div:last-child{
align-self:flex-end;
font-size:20px;
}
}

@media (max-width: 400px){

body{
padding:15px;
}

h1{
font-size:20px;
}

.candidate-card{
padding:16px;
}

.box{
padding:22px;
border-radius:14px;
}

button{
font-size:14px;
}
}

*{
    box-sizing:border-box;
    font-family:-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial;
}

body{
    margin:0;
    padding:24px;
    background: radial-gradient(circle at top, #f4fbf9 0%, #d8f3eb 100%);
    color:#1f2937;
}

/* CONTAINER */
.container{
    max-width:900px;
    margin:auto;
}

/* TÍTULO */
h1{
    color:#006642;
    font-size:clamp(20px, 4vw, 32px);
    margin-bottom:10px;
    text-align:center;
}

/* GRID RESPONSIVO REAL */
.candidates-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit, minmax(220px, 1fr));
    gap:14px;
    margin-top:24px;
}

/* CARD */
.candidate-card{
    background:white;
    padding:18px;
    border-radius:16px;
    cursor:pointer;
    display:flex;
    justify-content:space-between;
    align-items:center;
    border:2px solid transparent;
    box-shadow:0 10px 25px rgba(0,0,0,0.05);
    transition:0.2s ease;
}

.candidate-card:hover{
    transform:translateY(-2px);
}

/* selecionado */
.candidate-card.selected{
    border-color:#006642;
    background:#eafaf2;
}

/* textos */
.candidate-card h2{
    margin:5px 0 0;
    font-size:16px;
}

.candidate-card div{
    font-size:13px;
}

/* botão */
.actions{
    margin-top:24px;
    text-align:right;
}

button{
    background:#006642;
    color:white;
    border:none;
    padding:14px 22px;
    border-radius:12px;
    cursor:pointer;
    font-size:15px;
    transition:0.2s ease;
}

button:hover{
    background:#005236;
}

/* MODAL */
.modal{
    position:fixed;
    inset:0;
    background:rgba(0,0,0,0.45);
    display:none;
    justify-content:center;
    align-items:center;
    padding:16px;
}

.modal.show{
    display:flex;
}

.box{
    background:white;
    padding:24px;
    border-radius:16px;
    text-align:center;
    width:100%;
    max-width:360px;
}

/* 📱 MOBILE */
@media (max-width:600px){

    body{
        padding:14px;
    }

    .actions{
        text-align:center;
    }

    button{
        width:100%;
    }

    .candidate-card{
        flex-direction:column;
        align-items:flex-start;
        gap:10px;
    }

    .candidate-card div:last-child{
        align-self:flex-end;
    }
}
</style>

</head>

<body>

<div class="container">

<h1>Escolha seu candidato</h1>

<form
id="votacaoForm"
action="salvar_voto.php"
method="POST">

<div class="candidates-grid">

<?php while($candidato=$resultado->fetch_assoc()): ?>

<label
class="candidate-card"
onclick="selecionar(this)">

<input
type="radio"
name="candidato"
value="<?= $candidato["id"] ?>">

<div>

<div>

Nº
<?= $candidato["numero"] ?>

</div>

<h2>

<?= htmlspecialchars($candidato["nome"]) ?>

</h2>

</div>

<div>◯</div>

</label>

<?php endwhile; ?>

</div>

<div class="actions">

<button type="submit">

Confirmar voto

</button>

</div>

</form>

</div>


<!-- MODAL ERRO -->

<div
id="erroModal"
class="modal">

<div class="box">

<h2>

Selecione um candidato

</h2>

<button onclick="fecharErro()">

OK

</button>

</div>

</div>


<!-- MODAL SUCESSO -->

<div
id="sucessoModal"
class="modal">

<div class="box">

<h2>

✓ Voto enviado!

</h2>

<p>

Seu voto foi registrado com sucesso.

</p>

<button
onclick="voltar()">

OK

</button>

</div>

</div>


<script>

function selecionar(card){

document
.querySelectorAll(
".candidate-card"
)

.forEach(

c=>
c.classList.remove(
"selected"
)

);

card.classList.add(
"selected"
);

card.querySelector(
"input"
).checked=true;

}


document
.getElementById(
"votacaoForm"
)

.addEventListener(

"submit",

function(e){

if(

!document.querySelector(
'input[name="candidato"]:checked'
)

){

e.preventDefault();

document
.getElementById(
"erroModal"
)
.classList.add(
"show"
);

}

}

);


function fecharErro(){

document
.getElementById(
"erroModal"
)
.classList.remove(
"show"
);

}


function voltar(){

window.location=
"login.php";

}

<?php if($mostrarSucesso): ?>

window.onload=function(){

document
.getElementById(
"sucessoModal"
)

.classList.add(
"show"
);

};

<?php endif; ?>

</script>

</body>

</html>