<?php

include
"conexao.php";

$nome=
trim(
$_POST["nome"]
);

$numero=
intval(
$_POST["numero"]
);

$sql=
$conn->prepare(

"

INSERT INTO candidatos
(nome,numero)

VALUES (?,?)

"

);

$sql->bind_param(

"si",

$nome,

$numero

);

$sql->execute();

header(

"Location:
painel_admin.php"

);

exit;