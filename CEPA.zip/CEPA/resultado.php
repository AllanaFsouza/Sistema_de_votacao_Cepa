<?php

include
"conexao.php";

$sql=
"
SELECT

c.nome,

c.numero,

COUNT(v.id)
AS votos

FROM candidatos c

LEFT JOIN votos v

ON c.id=
v.candidato_id

GROUP BY c.id

ORDER BY votos DESC
";

$res=
$conn->query(
$sql
);

?>

<h1>
Resultado
</h1>

<?php

while(
$r=
$res->fetch_assoc()
):

?>

<p>

<?= htmlspecialchars(
$r["numero"]
) ?>

-

<?= htmlspecialchars(
$r["nome"]
) ?>

:

<?= $r["votos"] ?>

votos

</p>

<?php endwhile; ?>