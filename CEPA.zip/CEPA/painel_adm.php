<?php

session_start();

include "conexao.php";


$total=
$conn
->query(
"SELECT COUNT(*) total
FROM votos"
)
->fetch_assoc();

$candidatos=
$conn->query(

"

SELECT

c.id,

c.nome,

c.numero,

COUNT(v.id)
total

FROM candidatos c

LEFT JOIN votos v

ON c.id=
v.candidato_id

GROUP BY c.id

ORDER BY c.numero

"

);

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>
Painel ADM
</title>

</head>

<body>

<h1>
Painel
</h1>

<h2>

Total:

<?= $total["total"] ?>

</h2>

<form
action=
"candidato_salvar.php"

method=
"POST"

>

<input

name="nome"

placeholder=
"Nome"

required

>

<input

name="numero"

type=
"number"

required

>

<button>

Adicionar

</button>

</form>

<hr>

<table>

<tr>

<th>

Número

</th>

<th>

Nome

</th>

<th>

Votos

</th>

<th>

Ações

</th>

</tr>

<?php

while(
$c=
$candidatos
->fetch_assoc()
):

?>

<tr>

<td>

<?= $c["numero"] ?>

</td>

<td>

<?= htmlspecialchars(
$c["nome"]
) ?>

</td>

<td>

<?= $c["total"] ?>

</td>

<td>

<form

action=
"candidato_remover.php"

method=
"POST"

>

<input

type=
"hidden"

name=
"id"

value=
"<?= $c["id"] ?>"

>

<button>

Remover

</button>

</form>

</td>

</tr>

<?php endwhile; ?>

</table>

<br>

<a href="logout.php">

Sair

</a>

</body>

</html>