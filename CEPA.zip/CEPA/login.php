<?php
session_start();
include "conexao.php";


if($conn->connect_error){

die(
$conn->connect_error
);

}



if ($_SERVER["REQUEST_METHOD"]==="POST") {

$nome=
trim($_POST["nome"]);

$turma=
trim($_POST["turma"]);

$busca =
$conn->prepare(
"
SELECT id
FROM eleitores
WHERE nome=? AND turma=?
"
);

$busca->bind_param(
"ss",
$nome,
$turma
);

$busca->execute();

$res=
$busca
->get_result();

if(
$res->num_rows
){

$usuario=
$res->fetch_assoc();

$id=
$usuario["id"];

}else{


$insert =
$conn->prepare(
"
INSERT INTO eleitores
(
nome,
turma
)

VALUES
(
?,
?
)
"
);

$insert->bind_param(
"ss",
$nome,
$turma
);

if (!$insert->execute()) {

die(
"Erro SQL: ".
$conn->error
);

}

$id =
$conn->insert_id;

}

$_SESSION["eleitor"]=$id;

header(
"Location: votacao.php"
);

exit;

}
?>


<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CEPA - Sistema de Votação</title>
    <style>
        * {
            box-sizing: border-box;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
        }

        body {
            background-color: #e1f5fe; /* Tom de fundo verde-água bem claro */
            background: radial-gradient(circle, #f4fbf9 0%, #d8f3eb 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 20px;
        }

        .wrapper {
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 100%;
            max-width: 580px;
        }

        /* Ícone CEPA feito em CSS */
        .brand-icon {
            width: 56px;
            height: 56px;
            background-color: #006642;
            border-radius: 14px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            position: relative;
            box-shadow: 0 4px 10px rgba(0, 102, 66, 0.2);
            margin-bottom: 16px;
        }

        /* Simulação do monitor/check dentro do ícone */
        .brand-icon::before {
            content: '';
            width: 24px;
            height: 18px;
            border: 2px solid #ffffff;
            border-radius: 3px;
            position: absolute;
            top: 16px;
        }

        .brand-icon::after {
            content: '✓';
            color: #ffffff;
            font-size: 14px;
            font-weight: bold;
            position: absolute;
            top: 14px;
        }

        .brand-icon-base {
            width: 14px;
            height: 2px;
            background-color: #ffffff;
            position: absolute;
            bottom: 16px;
        }

        h1.brand-title {
            font-size: 28px;
            font-weight: 700;
            color: #006642;
            margin: 0 0 4px 0;
            letter-spacing: 0.5px;
        }

        p.brand-subtitle {
            font-size: 14px;
            color: #4a5568;
            margin: 0 0 32px 0;
        }

        /* Card de Login */
        .login-card {
            background-color: #ffffff;
            border-radius: 16px;
            padding: 40px;
            width: 100%;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
            margin-bottom: 24px;
        }

        .login-card h2 {
            font-size: 22px;
            color: #1a202c;
            margin: 0 0 6px 0;
            font-weight: 600;
        }

        .login-card p.instruction {
            font-size: 13px;
            color: #718096;
            margin: 0 0 24px 0;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-size: 14px;
            font-weight: 600;
            color: #1a202c;
            margin-bottom: 8px;
        }

        .form-group input {
            width: 100%;
            padding: 14px 16px;
            border: 1px solid #e2e8f0;
            background-color: #f7fafc;
            border-radius: 10px;
            font-size: 15px;
            color: #2d3748;
            outline: none;
            transition: all 0.2s ease;
        }

        .form-group input:focus {
            border-color: #006642;
            background-color: #ffffff;
            box-shadow: 0 0 0 3px rgba(0, 102, 66, 0.1);
        }

        .form-group input::placeholder {
            color: #a0aec0;
        }

        /* Botão */
        .btn-submit {
            width: 100%;
            background-color: #006642;
            color: #ffffff;
            border: none;
            padding: 14px;
            font-size: 15px;
            font-weight: 600;
            border-radius: 10px;
            cursor: pointer;
            transition: background-color 0.2s ease;
            margin-top: 8px;
        }

        .btn-submit:hover {
            background-color: #004d32;
        }

        /* Link do Administrador */
        .admin-footer {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            text-decoration: none;
            color: #718096;
            font-size: 13px;
            transition: color 0.2s ease;
        }

        .admin-footer:hover {
            color: #4a5568;
        }

        .admin-footer svg {
            width: 16px;
            height: 16px;
            fill: none;
            stroke: currentColor;
            stroke-width: 2;
        }

        /* ESTRUTURA DO MODAL PERSONALIZADO */
        .modal-overlay {
            position: fixed;
            inset: 0;
            background-color: rgba(0, 0, 0, 0.4);
            backdrop-filter: blur(3px);
            display: flex;
            justify-content: center;
            align-items: center;
            opacity: 0;
            visibility: hidden;
            transition: all 0.25s ease-in-out;
            z-index: 999;
        }

        /* Classe que ativa a exibição do modal */
        .modal-overlay.show {
            opacity: 1;
            visibility: visible;
        }

        .modal-box {
            background-color: #ffffff;
            width: 100%;
            max-width: 400px;
            padding: 32px;
            border-radius: 20px;
            text-align: center;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.12);
            transform: translateY(20px);
            transition: transform 0.25s ease-in-out;
        }

        .modal-overlay.show .modal-box {
            transform: translateY(0);
        }

        .modal-icon {
            width: 60px;
            height: 60px;
            background-color: #fff5f5;
            color: #e53e3e;
            border: 2px solid #fed7d7;
            border-radius: 50%;
            font-size: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 18px;
        }

        .modal-box h3 {
            font-size: 20px;
            color: #1a202c;
            margin: 0 0 10px 0;
            font-weight: 700;
        }

        .modal-box p {
            font-size: 14px;
            color: #718096;
            line-height: 1.5;
            margin: 0 0 24px 0;
        }

        .btn-modal-close {
            width: 100%;
            background-color: #e53e3e;
            color: #ffffff;
            border: none;
            padding: 12px;
            font-size: 15px;
            font-weight: 600;
            border-radius: 10px;
            cursor: pointer;
            transition: background-color 0.2s ease;
        }

        .btn-modal-close:hover {
            background-color: #c53030;
        }
        /* VALIDAÇÃO */

.erro {
    display: block;
    margin-top: 6px;
    color: #e53e3e;
    font-size: 12px;
}

.input-erro {
    border-color: #e53e3e !important;
    background-color: #fff5f5 !important;
}

.input-sucesso {
    border-color: #006642 !important;
}

* {
    box-sizing: border-box;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
}

body {
    background: radial-gradient(circle, #f4fbf9 0%, #d8f3eb 100%);
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    margin: 0;
    padding: 20px;
}

/* CONTAINER */
.wrapper {
    display: flex;
    flex-direction: column;
    align-items: center;
    width: 100%;
    max-width: 580px;
}

/* LOGO */
.brand-icon {
    width: 56px;
    height: 56px;
    background-color: #006642;
    border-radius: 14px;
    display: flex;
    justify-content: center;
    align-items: center;
    position: relative;
    box-shadow: 0 4px 10px rgba(0, 102, 66, 0.2);
    margin-bottom: 16px;
}

.brand-icon::before {
    content: '';
    width: 24px;
    height: 18px;
    border: 2px solid #fff;
    border-radius: 3px;
    position: absolute;
    top: 16px;
}

.brand-icon::after {
    content: '✓';
    color: #fff;
    font-size: 14px;
    font-weight: bold;
    position: absolute;
    top: 14px;
}

.brand-icon-base {
    width: 14px;
    height: 2px;
    background: #fff;
    position: absolute;
    bottom: 16px;
}

/* TITULOS */
.brand-title {
    font-size: 28px;
    font-weight: 700;
    color: #006642;
    margin: 0 0 4px 0;
}

.brand-subtitle {
    font-size: 14px;
    color: #4a5568;
    margin-bottom: 24px;
    text-align: center;
}

/* CARD */
.login-card {
    background: #fff;
    border-radius: 16px;
    padding: 32px;
    width: 100%;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
}

.login-card h2 {
    font-size: 22px;
    margin: 0 0 6px;
}

.instruction {
    font-size: 13px;
    color: #718096;
    margin-bottom: 20px;
}

/* FORM */
.form-group {
    margin-bottom: 18px;
}

label {
    display: block;
    font-size: 14px;
    font-weight: 600;
    margin-bottom: 6px;
}

input {
    width: 100%;
    padding: 14px;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    background: #f7fafc;
    font-size: 15px;
    outline: none;
    transition: 0.2s;
}

input:focus {
    border-color: #006642;
    background: #fff;
    box-shadow: 0 0 0 3px rgba(0, 102, 66, 0.1);
}

/* BOTÃO */
.btn-submit {
    width: 100%;
    background: #006642;
    color: #fff;
    border: none;
    padding: 14px;
    font-size: 15px;
    font-weight: 600;
    border-radius: 10px;
    cursor: pointer;
    transition: 0.2s;
}

.btn-submit:hover {
    background: #004d32;
}

/* LINK ADMIN */
.admin-footer {
    margin-top: 20px;
    font-size: 13px;
    color: #718096;
    display: flex;
    align-items: center;
    gap: 6px;
    text-decoration: none;
}

/* ERROS */
.erro {
    color: #e53e3e;
    font-size: 12px;
    margin-top: 6px;
    display: block;
}

.input-erro {
    border-color: #e53e3e !important;
    background: #fff5f5 !important;
}

.input-sucesso {
    border-color: #006642 !important;
}

/* MODAL */
.modal-overlay {
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.4);
    display: flex;
    justify-content: center;
    align-items: center;
    opacity: 0;
    visibility: hidden;
    transition: 0.25s ease;
    padding: 20px;
}

.modal-overlay.show {
    opacity: 1;
    visibility: visible;
}

.modal-box {
    background: #fff;
    width: 100%;
    max-width: 400px;
    padding: 28px;
    border-radius: 18px;
    text-align: center;
    transform: translateY(15px);
    transition: 0.25s ease;
}

.modal-overlay.show .modal-box {
    transform: translateY(0);
}

.modal-icon {
    width: 55px;
    height: 55px;
    margin: 0 auto 15px;
    background: #fff5f5;
    border: 2px solid #fed7d7;
    color: #e53e3e;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
}

.btn-modal-close {
    margin-top: 20px;
    width: 100%;
    padding: 12px;
    border: none;
    background: #e53e3e;
    color: #fff;
    border-radius: 10px;
    cursor: pointer;
}

/* RESPONSIVO */
@media (max-width: 600px) {

    .login-card {
        padding: 22px;
    }

    .brand-title {
        font-size: 24px;
    }

    input {
        padding: 12px;
    }

    .btn-submit {
        padding: 12px;
    }
}

@media (max-width: 400px) {

    .wrapper {
        padding: 10px;
    }

    .login-card {
        padding: 18px;
    }
}

    </style>
</head>
<body>

    <div class="wrapper">
        <div class="brand-icon">
            <div class="brand-icon-base"></div>
        </div>
        
        <h1 class="brand-title">CEPA</h1>
        <p class="brand-subtitle">Sistema de Votação</p>

        <div class="login-card">
            <h2>Identifique-se</h2>
            <p class="instruction">Informe seu nome e matrícula para votar.</p>

<form id="loginForm" action="" method="POST">
    <div class="form-group">
        <label for="nome">Nome completo</label>

        <input
            type="text"
            id="nome"
            name="nome"
            placeholder="Seu nome"
            autocomplete="off"
        >

        <small class="erro"></small>
    </div>

    <div class="form-group">
        <label for="turma">Turma</label>

        <input
            type="text"
            id="turma"
            name="turma"
            placeholder="Ex: Informática"
            autocomplete="off"
        >

        <small class="erro"></small>
    </div>

    <button type="submit" class="btn-submit">
        Entrar para votar
    </button>

</form>
        </div>

        <a href="login_adm.php" class="admin-footer">
            <svg viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                <path d="m9 11 2 2 4-4"></path>
            </svg>
            Acesso administrador
        </a>
    </div>

<script>

const form = document.getElementById("loginForm");
const modal = document.getElementById("validationModal");

const nome = document.getElementById("nome");
const turma = document.getElementById("turma");

function mostrarErro(campo, mensagem) {

    campo.classList.add("input-erro");
    campo.classList.remove("input-sucesso");

    campo.parentElement
        .querySelector(".erro")
        .textContent = mensagem;
}

function limparErro(campo) {

    campo.classList.remove("input-erro");

    if (campo.value.trim() !== "") {
        campo.classList.add("input-sucesso");
    }

    campo.parentElement
        .querySelector(".erro")
        .textContent = "";
}

form.addEventListener("submit", function(e) {

    e.preventDefault();

    let valido = true;

    const nomeValor = nome.value.trim();
    const turmaValor = turma.value.trim();

    // Nome
    if (nomeValor === "") {
        mostrarErro(nome, "Informe seu nome.");
        valido = false;

    } else if (nomeValor.length < 3) {
        mostrarErro(nome, "Digite pelo menos 3 caracteres.");
        valido = false;

    } else {
        limparErro(nome);
    }

    // Turma
    if (turmaValor === "") {
        mostrarErro(turma, "Informe sua turma.");
        valido = false;

    } else if (turmaValor.length < 3) {
        mostrarErro(turma, "Turma inválida.");
        valido = false;

    } else {
        limparErro(turma);
    }

    if (!valido) {
        modal.classList.add("show");
        return;
    }

    form.submit();

});

[nome, turma].forEach(campo => {

    campo.addEventListener("input", () => {

        if (campo.value.trim() !== "") {
            limparErro(campo);
        }

    });

});

function fecharModal() {
    modal.classList.remove("show");
}

modal.addEventListener("click", function(e) {

    if (e.target === modal) {
        fecharModal();
    }

});

</script>

<div id="validationModal" class="modal-overlay">
    <div class="modal-box">
        <div class="modal-icon">!</div>
        <h3>Ops! Verifique os dados</h3>
        <p>Por favor, preencha os campos corretamente antes de prosseguir com a votação.</p>
        <button type="button" class="btn-modal-close" onclick="fecharModal()">Entendido</button>
    </div>
</div>


</body>
</html>