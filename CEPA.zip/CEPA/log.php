<?php


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);




session_start();

include "conexao.php";

if (
!isset($_POST["matricula"]) ||
!isset($_POST["senha"])
) {
    die("Dados inválidos");
}

$matricula =
trim($_POST["matricula"]);

$senha =
hash(
"sha256",
$_POST["senha"]
);

$sql =
$conn->prepare(
"
SELECT *
FROM eleitores
WHERE matricula=?
AND senha=?
"
);

$sql->bind_param(
"ss",
$matricula,
$senha
);

$sql->execute();

$res =
$sql
->get_result();

if(
$res->num_rows===0
){

header(
"Location: login.php"
);

exit;

}

$usuario =
$res->fetch_assoc();

$_SESSION["eleitor"] =
$usuario["id"];

header(
"Location: votar.php"
);

exit;

?>