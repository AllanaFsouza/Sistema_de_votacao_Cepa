<?php
include "conexao.php";
session_start();

if (!isset($_SESSION["admin"])) {
header("Location: login_adm.php");
exit;
}

$id = $_POST["id"] ?? null;
$nome = trim($_POST["nome"] ?? "");

if (!$id || $nome == "") {
header("Location: " . $_SERVER['HTTP_REFERER']);
exit;
}

$stmt = $conn->prepare("
UPDATE candidatos
SET nome = ?
WHERE id = ?
");

$stmt->bind_param("si", $nome, $id);
$stmt->execute();

/* 🔥 FORÇA VOLTAR E RECARREGAR TUDO */
header("Location: " . $_SERVER['HTTP_REFERER']);
exit;
?>