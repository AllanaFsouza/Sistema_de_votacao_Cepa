-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 24/06/2026 às 23:58
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `votacao_cepa`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `candidatos`
--

CREATE TABLE `candidatos` (
  `id` int(11) NOT NULL,
  `nome` varchar(150) NOT NULL,
  `numero` int(11) NOT NULL,
  `turma` varchar(100) DEFAULT NULL,
  `proposta` text DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `total_votos` int(11) DEFAULT 0,
  `data_cadastro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `candidatos`
--

INSERT INTO `candidatos` (`id`, `nome`, `numero`, `turma`, `proposta`, `foto`, `total_votos`, `data_cadastro`) VALUES
(4, 'Candidato 1', 1, NULL, NULL, NULL, 0, '2026-06-23 23:19:29'),
(5, 'Candidato 2', 2, NULL, NULL, NULL, 0, '2026-06-23 23:19:29'),
(6, 'Candidato 3', 3, NULL, NULL, NULL, 0, '2026-06-23 23:19:29'),
(7, 'Candidato 4', 4, NULL, NULL, NULL, 0, '2026-06-23 23:19:29'),
(8, 'Candidato 5', 5, NULL, NULL, NULL, 0, '2026-06-23 23:19:29'),
(9, 'Candidato 6', 6, NULL, NULL, NULL, 0, '2026-06-23 23:19:29'),
(10, 'Candidato 7', 7, NULL, NULL, NULL, 0, '2026-06-23 23:19:29'),
(11, 'Candidato 8', 8, NULL, NULL, NULL, 0, '2026-06-23 23:19:29'),
(12, 'Candidato 9', 9, NULL, NULL, NULL, 0, '2026-06-23 23:19:29'),
(13, 'Candidato 10', 10, NULL, NULL, NULL, 0, '2026-06-23 23:19:29');

-- --------------------------------------------------------

--
-- Estrutura para tabela `eleitores`
--

CREATE TABLE `eleitores` (
  `id` int(11) NOT NULL,
  `Nome` varchar(150) NOT NULL,
  `Turma` varchar(50) NOT NULL,
  `data_cadastro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `instrutores`
--

CREATE TABLE `instrutores` (
  `id` int(11) NOT NULL,
  `nome` varchar(150) NOT NULL,
  `data_acesso` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura stand-in para view `resultado_votos`
-- (Veja abaixo para a visão atual)
--
CREATE TABLE `resultado_votos` (
`id` int(11)
,`eleitor` varchar(150)
,`turma` varchar(50)
,`candidato` varchar(150)
);

-- --------------------------------------------------------

--
-- Estrutura para tabela `votos`
--

CREATE TABLE `votos` (
  `id` int(11) NOT NULL,
  `eleitor_id` int(11) NOT NULL,
  `candidato_id` int(11) NOT NULL,
  `data_voto` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para view `resultado_votos`
--
DROP TABLE IF EXISTS `resultado_votos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `resultado_votos`  AS SELECT `v`.`id` AS `id`, `e`.`Nome` AS `eleitor`, `e`.`Turma` AS `turma`, `c`.`nome` AS `candidato` FROM ((`votos` `v` join `eleitores` `e` on(`v`.`eleitor_id` = `e`.`id`)) join `candidatos` `c` on(`v`.`candidato_id` = `c`.`id`)) ;

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `candidatos`
--
ALTER TABLE `candidatos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `numero` (`numero`);

--
-- Índices de tabela `eleitores`
--
ALTER TABLE `eleitores`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `instrutores`
--
ALTER TABLE `instrutores`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `votos`
--
ALTER TABLE `votos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `voto_unico` (`eleitor_id`),
  ADD KEY `fk_candidato` (`candidato_id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `candidatos`
--
ALTER TABLE `candidatos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de tabela `eleitores`
--
ALTER TABLE `eleitores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT de tabela `instrutores`
--
ALTER TABLE `instrutores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de tabela `votos`
--
ALTER TABLE `votos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `votos`
--
ALTER TABLE `votos`
  ADD CONSTRAINT `fk_candidato` FOREIGN KEY (`candidato_id`) REFERENCES `candidatos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_eleitor` FOREIGN KEY (`eleitor_id`) REFERENCES `eleitores` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
