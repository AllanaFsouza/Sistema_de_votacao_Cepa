<?php
session_start();

if(
!isset($_SESSION["eleitor"])
){

header(
"Location: index.html"
);

exit;

}
?>

<form
action="salvar_voto.php"
method="POST"
>

<label>

<input
type="radio"
name="candidato"
value="1"
required

>

Candidato 1

</label>

<br>

<label>

<input
type="radio"
name="candidato"
value="2"

>

Candidato 2

</label>

<br><br>

<button>

Confirmar voto

</button>

</form>