<?php

$servername = "sql113.infinityfree.com"; // ← seu servidor MySQL
$username   = "if0_42263990";            // ← usuário do banco
$password   = "5wEbcpPqVx";     // ← senha do MySQL
$dbname     = "if0_42263990_votacao_cepa";            // ← nome do banco

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
?>